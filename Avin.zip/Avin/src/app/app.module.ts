import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddAvinComponent } from './add-avin/add-avin.component';
import { UpdateAvinComponent } from './update-avin/update-avin.component';
import { LoginAvinComponent } from './login-avin/login-avin.component';
import { RegisterAvinComponent } from './register-avin/register-avin.component';
import { ListAvinComponent } from './list-avin/list-avin.component';
import { HttpClientModule } from '@angular/common/http';
import { ListServiceService } from './service/list-service.service';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FilterPipe } from './PipeFile/filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AddAvinComponent,
    UpdateAvinComponent,
    LoginAvinComponent,
    RegisterAvinComponent,
    ListAvinComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [ListServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }

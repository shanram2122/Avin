import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAvinComponent } from './list-avin.component';

describe('ListAvinComponent', () => {
  let component: ListAvinComponent;
  let fixture: ComponentFixture<ListAvinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListAvinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAvinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

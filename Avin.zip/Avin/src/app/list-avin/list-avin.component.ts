import { Component, OnInit } from '@angular/core';
import { ListServiceService } from '../service/list-service.service';

@Component({
  selector: 'app-list-avin',
  templateUrl: './list-avin.component.html',
  styleUrls: ['./list-avin.component.css']
})
export class ListAvinComponent implements OnInit {
producerName:string;
  constructor(private getListService:ListServiceService) { }
getListData:any = [];
  ngOnInit(): void {
    this.getListService.getList().subscribe((res)=>{
      console.log(res);
      this.getListData=res;
    })
  }
deleteProducer(item)
{
  confirm("Do u want delete");
  this.getListData.splice(item-1,1);
  this.getListService.deleteItem(item).subscribe((res)=>{
    console.log("Deleted Producer" + res);
  })
}
isActiveFor:boolean=false;
isActive:boolean=true;
showTable()
{
  this.isActiveFor=true;
  this.isActive=false;
}
}

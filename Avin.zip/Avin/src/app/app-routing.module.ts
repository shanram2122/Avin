import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAvinComponent } from './add-avin/add-avin.component';
import { UpdateAvinComponent } from './update-avin/update-avin.component';
import { LoginAvinComponent } from './login-avin/login-avin.component';
import { RegisterAvinComponent } from './register-avin/register-avin.component';
import { ListAvinComponent } from './list-avin/list-avin.component';


const routes: Routes = [
  {path:'add',component:AddAvinComponent},
  {path:'update/:id',component:UpdateAvinComponent},
  // {path:'login',component:LoginAvinComponent},
  // {path:'register',component:RegisterAvinComponent},
  {path:'list',component:ListAvinComponent},
  {path:'',component:ListAvinComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

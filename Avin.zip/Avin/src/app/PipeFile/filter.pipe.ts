import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'producerFilter'
})
export class FilterPipe implements PipeTransform {

  transform(users,proName:string):[] {
    if(!users || !proName )
    {
      return users;
    }
    return users.filter(res=>{
      
        return res.proName.toLowerCase().indexOf(proName.toLowerCase())!==-1;
      })
    }
}

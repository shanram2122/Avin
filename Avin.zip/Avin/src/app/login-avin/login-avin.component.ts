import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-avin',
  templateUrl: './login-avin.component.html',
  styleUrls: ['./login-avin.component.css']
})
export class LoginAvinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

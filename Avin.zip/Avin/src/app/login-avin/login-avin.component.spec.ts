import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginAvinComponent } from './login-avin.component';

describe('LoginAvinComponent', () => {
  let component: LoginAvinComponent;
  let fixture: ComponentFixture<LoginAvinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginAvinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginAvinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

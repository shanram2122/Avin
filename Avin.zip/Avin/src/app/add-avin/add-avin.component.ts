import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup, Validators} from '@angular/forms';
import { ListServiceService } from '../service/list-service.service';
@Component({
  selector: 'app-add-avin',
  templateUrl: './add-avin.component.html',
  styleUrls: ['./add-avin.component.css']
})
export class AddAvinComponent implements OnInit {
alert:boolean=false;
addProducer=new FormGroup({
  proId:new FormControl('',Validators.required),
  proName:new FormControl('',Validators.required),
  proHusband:new FormControl('',Validators.required),
  proPhone:new FormControl('',Validators.required),
  proAdhar:new FormControl('',Validators.required)
})
get proId(){
  return this.addProducer.get('proId');
  
}
get proName(){
  return this.addProducer.get('proName');
  
}
get proHusband(){
  return this.addProducer.get('proHusband');
  
}
get proPhone(){
  return this.addProducer.get('proPhone');
  
}
get proAdhar(){
  return this.addProducer.get('proAdhar');
  
}
addProducerData(addProducer)
{
  this.saveProducerData.saveProducer(addProducer).subscribe((res)=>
  {
    this.alert=true;
    this.addProducer.reset({});
  })
}
closeAlert()
{
  this.alert=false;
}
  constructor(private saveProducerData:ListServiceService) { }

  ngOnInit(): void {
  }

}

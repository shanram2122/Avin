import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAvinComponent } from './add-avin.component';

describe('AddAvinComponent', () => {
  let component: AddAvinComponent;
  let fixture: ComponentFixture<AddAvinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAvinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAvinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-avin',
  templateUrl: './register-avin.component.html',
  styleUrls: ['./register-avin.component.css']
})
export class RegisterAvinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

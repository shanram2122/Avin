import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterAvinComponent } from './register-avin.component';

describe('RegisterAvinComponent', () => {
  let component: RegisterAvinComponent;
  let fixture: ComponentFixture<RegisterAvinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterAvinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterAvinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

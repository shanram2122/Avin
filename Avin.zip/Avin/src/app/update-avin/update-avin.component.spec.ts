import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateAvinComponent } from './update-avin.component';

describe('UpdateAvinComponent', () => {
  let component: UpdateAvinComponent;
  let fixture: ComponentFixture<UpdateAvinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateAvinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateAvinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

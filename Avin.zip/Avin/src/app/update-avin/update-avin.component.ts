import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
import {ActivatedRoute} from '@angular/router';
import { ListServiceService } from '../service/list-service.service';
@Component({
  selector: 'app-update-avin',
  templateUrl: './update-avin.component.html',
  styleUrls: ['./update-avin.component.css']
})
export class UpdateAvinComponent implements OnInit {
  editProducer=new FormGroup({
    proId:new FormControl(''),
    proName:new FormControl(''),
    proHusband:new FormControl(''),
    proPhone:new FormControl(''),
    proAdhar:new FormControl('')
  })
  constructor(private router:ActivatedRoute,private listService:ListServiceService) { }
alert:boolean=false;
  ngOnInit(): void {
    console.log(this.router.snapshot.params.id);
    this.listService.editableProducer(this.router.snapshot.params.id).
    subscribe((result)=>{
      this.editProducer=new FormGroup({
        proId:new FormControl(result['proId']),
        proName:new FormControl(result['proName']),
        proHusband:new FormControl(result['proHusband']),
        proPhone:new FormControl(result['proPhone']),
        proAdhar:new FormControl(result['proAdhar'])
      })
    });
  }
  closeAlert()
  {
    this.alert=false;
  }
  updatedForm()
  {
    console.log(this.editProducer.value);
    this.listService.updateFormData(this.router.snapshot.params.id,this.editProducer.value);
    this.alert=true;
    this.editProducer.reset({});
  }
}

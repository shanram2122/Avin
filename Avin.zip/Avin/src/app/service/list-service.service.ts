import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ListServiceService {
url="http://localhost:3000/AragalurAvin";
  constructor(private http:HttpClient) { }
  getList()
  {
    return this.http.get(this.url);
  }
  saveProducer(data:any)
  {
    return this.http.post(this.url,data);
  }
  deleteItem(item:any)
  {
    return this.http.delete(`${this.url}/${item}`);
  }
  editableProducer(id:any)
  {
    return this.http.get(`${this.url}/${id}`);
  }
  updateFormData(id,data)
  {
   return this.http.put(`${this.url}/${id}`,data).
   subscribe((result)=>{
     console.log(result);
   }); 
  }
}
